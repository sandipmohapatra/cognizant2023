package com.spring.exception;

public class InvalidParcelWeightException extends Exception {
	public InvalidParcelWeightException(String message) {
		super(message);
	}
}

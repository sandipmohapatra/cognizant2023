# ZeeZee Bank

> Sample Input and Output 1:

    Enter the account number:
    9876543210
    Enter initial balance:
    15000
    Enter the amount to be deposited:
    1500
    Available balance is:16500.00
    Enter the amount to be withdrawn:
    500
    Available balance is:16000.00

> Sample Input and Output 2:

    Enter the account number:
    9876543210
    Enter initial balance:
    15000
    Enter the amount to be deposited:
    1500
    Available balance is:16500.00
    Enter the amount to be withdrawn:
    18500
    Insufficient balance
    Available balance is:16500.00
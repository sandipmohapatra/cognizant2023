public interface NumberType {
    boolean checkNumber(int num);
}

# car rental system - Insert values

Refer to the given schema diagram. Insert the below records into Rentals Table. Assume the rentals table has been already created.

![table data](table_data.png)

*Note: Letters in bold represent the attributes.*

*NOTE: Maintain the same sequence of column order, as specified in the question description*

![database diagram](../database_2.png)
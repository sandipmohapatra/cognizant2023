UPDATE customers
SET phone_no = 9876543210
WHERE customer_id = "CUST1004";
# Hunger eats - update table

Refer to the given schema diagram and sample records inserted into the Customers table.

![table data][table_data.png]

Update records based on the given requirement.

> Requirement 1: update the phone no of the Customers whose id is 'CUST1004' to the new phone no  '9876543210'

*NOTE: Maintain the same sequence of column order, as specified in the question description*

![database diagram](../database_3.png)
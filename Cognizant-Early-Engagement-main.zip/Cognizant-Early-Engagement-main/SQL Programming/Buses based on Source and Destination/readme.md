# Buses based on Source and Destination

Write a query to display the list of bus numbers and names where the source and destination of a bus is the destination and source of another bus. Display the unique records in ascending order by bus_no.

> **Note:** 
> Evaluate only the respective query to get the desired result.

![database diagram](../../../database_4.jpg)
# Patient Appointment details Based On Month

Refer to the schema. Write a query to display unique patient id, patient first name, patient age, address and contact number of all the patients who booked appointments in the month of JUNE 2019. Sort the records based on patient id.

> Hint: 

Use Patient & Appointment tables. The appointment date will be in the format 'YYYY-MM-DD'.

![database diagram](database_diagram.png)
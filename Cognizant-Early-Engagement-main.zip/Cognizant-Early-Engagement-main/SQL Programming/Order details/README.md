# Order details

Write a query to display order id, customer name, hotel name, and order amount of all orders. Sort the result based on order id in ascending order.

> HINT: Use Customers, Hotel_details and Orders tables to retrieve records.

*NOTE: Maintain the same sequence of column order, as specified in the question description*

![database diagram](../database_3.png)
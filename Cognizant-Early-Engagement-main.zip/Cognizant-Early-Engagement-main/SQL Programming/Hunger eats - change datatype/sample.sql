ALTER TABLE customers
    MODIFY COLUMN customer_id int;
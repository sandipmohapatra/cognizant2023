# Hunger eats - Change the field name

Write appropriate query/queries for the given requirement. Assume, Hotel_Details table has been already created.

Requirement 1: Change the name of the existing field Rating to Hotel_Rating in the  Hotel_Details table.

*Note: Letters in the bold represents the attributes*

![database diagram](../database_3.png)
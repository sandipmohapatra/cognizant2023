package com.cognizant.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.beans.Person;
import com.cognizant.beans.Voter;
import com.cognizant.utilities.Connector;

public class VotersDaoImpl implements VotersDao{
	
	
	public List<Person>readFromFile() throws FileNotFoundException,IOException,ParseException
	{
		
		//insert the implementing code here
		List<Person>persons=null;
		
		return persons;
	}
	public void writeToDatabase(List<Voter> voters) throws ClassNotFoundException,SQLException,FileNotFoundException,IOException 
	{
		//insert the implementing code here
		
				
	}

}

package com.cognizant.bo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.cognizant.beans.Person;
import com.cognizant.beans.Voter;
import com.cognizant.dao.VotersDao;
import com.cognizant.dao.VotersDaoImpl;

public class VotersBoImpl implements VotersBo {
	
	public void prepareVotersList() throws ParseException,ClassNotFoundException,FileNotFoundException,SQLException

	{
		VotersDao vd=null;
		List<Voter>votersList=null;
		try
		{
		//Provide the implementation code
		
		vd.writeToDatabase(votersList);
		}
		
		catch(FileNotFoundException fne)
		{
			fne.printStackTrace();
		}
		catch(IOException io)
		{
			io.printStackTrace();
		}
		
		
		
		
	}

}

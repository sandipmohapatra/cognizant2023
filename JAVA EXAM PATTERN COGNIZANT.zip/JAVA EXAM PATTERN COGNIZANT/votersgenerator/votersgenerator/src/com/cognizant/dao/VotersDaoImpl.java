package com.cognizant.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.beans.Person;
import com.cognizant.beans.Voter;
import com.cognizant.utilities.Connector;

public class VotersDaoImpl implements VotersDao{
	
	
	public List<Person>readFromFile() throws FileNotFoundException,IOException,ParseException
	{
		
		//insert the implementing code here
		List<Person>persons=null;
		//Creating an empty ArrayList to hold 'Person' objects
		persons=new ArrayList<Person>();
		//Creating a BufferedReader object for reading from the file
		BufferedReader br=new BufferedReader(new FileReader("./src/com/cognizant/utilities/persons.txt"));
		//Reading each line from the file
		String strRec=null;
		while((strRec=br.readLine())!=null)
		{
			String[] record=strRec.split(",");
			//Creating a new 'Person' object with the details from the array
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			sdf.setLenient(false);
			Date dob=sdf.parse(record[3]);
			System.out.println("DOB :"+dob);
			Person person=new Person(record[0],record[1],Integer.parseInt(record[2]),dob);
			System.out.println("Person created..");
			persons.add(person);
		}
		return persons;
	}
	public void writeToDatabase(List<Voter> voters) throws ClassNotFoundException,SQLException,FileNotFoundException,IOException 
	{
		//insert the implementing code here
		System.out.println("Write to database called...");
		Connection con=Connector.getConnection();
		String insertString="insert into voters(name,address,ward_no,age) values(?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(insertString);
		for(Voter voter:voters)
		{
			pstmt.setString(1, voter.getName());
			pstmt.setString(2,voter.getAddress());
			pstmt.setInt(3, voter.getWardNo());
			pstmt.setInt(4,voter.getAge());
			pstmt.executeUpdate();
		}
				
	}

}

package com.cognizant.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.cognizant.beans.Person;
import com.cognizant.beans.Voter;

public interface VotersDao {
	
	/* 
	 * This method should be responsible for reading all the persons'
	 * details from the comma delimited file, 'persons.txt', from each line
	 * create a 'Person' object and add it to an ArrayList and finally return
	 * the list to the 'BO' method from where it is called
	 */
	List<Person>readFromFile() throws FileNotFoundException,IOException,ParseException;
	/* This method should receive all the eligible voters' list handed over 
	 * to it from the 'BO' method and write the voters' details to the database table,
	 * 'voters'.
	 */
	void writeToDatabase(List<Voter> voters)throws ClassNotFoundException,SQLException,FileNotFoundException,IOException; 

}

package com.cognizant;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.text.ParseException;

import com.cognizant.bo.VotersBo;
import com.cognizant.bo.VotersBoImpl;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		VotersBo vbo=new VotersBoImpl();
		//The method with the help of the 'Dao' object should
		//read from the file 'persons.txt', prepare a voters list
		//and then write the voters' list with the help of the 'Dao' object
		try {
			vbo.prepareVotersList();
		} catch (ClassNotFoundException | FileNotFoundException | ParseException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

/* An object of this class should represent any person
 * 
 */
package com.cognizant.beans;

import java.util.Date;

public class Person {
	private String name;
	private String address;
	private int wardNo;
	private Date dob;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getWardNo() {
		return wardNo;
	}
	public void setWardNo(int wardNo) {
		this.wardNo = wardNo;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Person(String name, String address, int wardNo, Date dob) {
		super();
		this.name = name;
		this.address = address;
		this.wardNo = wardNo;
		this.dob = dob;
	}
	
	
	
	

}

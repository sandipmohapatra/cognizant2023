package com.cognizant.bo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.cognizant.beans.Person;
import com.cognizant.beans.Voter;
import com.cognizant.dao.VotersDao;
import com.cognizant.dao.VotersDaoImpl;

public class VotersBoImpl implements VotersBo {
	
	public void prepareVotersList() throws ParseException,ClassNotFoundException,FileNotFoundException,SQLException

	{
		System.out.println("Inside prepareVotersList()");
		List<Voter>votersList=null;
		//Provide the implementing code to prepare the voters' list
		//Creating an object of 'VotersDao'
		VotersDao vd=new VotersDaoImpl();
		votersList =new ArrayList<Voter>();
		try
		{
		List<Person>persons=vd.readFromFile();
		System.out.println("no of persons="+persons.size());
		for(Person p:persons)
		{
			Date dob=p.getDob();
			//Creating 2 'Calendar' objects that by default get initialised
			//with the current date
			Calendar cal1=Calendar.getInstance();
			Calendar cal2=Calendar.getInstance();
			//Initialising 'cal2' with dob
			cal2.setTime(dob);
			int age=(int)((cal1.getTimeInMillis()-cal2.getTimeInMillis())/(1000*60*60*24*365L));
			System.out.println("Age is"+age);
			if(age>=18)
			{
				Voter voter=new Voter();
				voter.setName(p.getName());
				voter.setAddress(p.getAddress());
				voter.setWardNo(p.getWardNo());
				voter.setAge(age);
				votersList.add(voter);
			}
			//writing the 'votersList' with the help of the 'Dao' object
			// to the database table
			
		}
		vd.writeToDatabase(votersList);
		}
		
		catch(FileNotFoundException fne)
		{
			fne.printStackTrace();
		}
		catch(IOException io)
		{
			io.printStackTrace();
		}
		catch(ParseException p)
		{
			p.printStackTrace();
		}
		
		
		
	}

}

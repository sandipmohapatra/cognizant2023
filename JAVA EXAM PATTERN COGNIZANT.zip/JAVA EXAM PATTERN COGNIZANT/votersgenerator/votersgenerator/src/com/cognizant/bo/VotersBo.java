package com.cognizant.bo;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.cognizant.beans.Voter;

public interface VotersBo {
	/* This method with the help of the 'Dao' object will get
	 * the list of 'Person's objects,will retrieve each person's details
	 * , calculate the age from the 'dob'and if the age is found to be >=18
	 * years, a 'Voter' object is to be created and added to an ArrayList
	 *
	 * 
	 * After that this method with the help of the 'Dao' object should write all
	 * the eligible voters' details from the list to the database
	 */
	void prepareVotersList() throws ParseException,ClassNotFoundException,FileNotFoundException,SQLException;

}

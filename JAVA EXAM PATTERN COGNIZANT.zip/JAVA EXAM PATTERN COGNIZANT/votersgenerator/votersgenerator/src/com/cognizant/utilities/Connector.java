package com.cognizant.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Connector {
	
	static Connection con=null;
	public static Connection getConnection()
	{
		System.out.println("Hello");
		ResourceBundle rb=ResourceBundle.getBundle("com.cognizant.utilities.connection");
		String driver=rb.getString("driver");
		String url=rb.getString("url");
		String username=rb.getString("username");
		String password=rb.getString("password");
		try
		{
			Class.forName(driver);
			System.out.println("Driver loaded");
			con=DriverManager.getConnection(url,username,password);
			System.out.println("connected");
		}
		catch(ClassNotFoundException cnf)
		{
			cnf.printStackTrace();
		}
		catch(SQLException sql)
		{
			sql.printStackTrace();
		}
		return con;
	}

}

create table voters
(
  id integer primary key auto_increment,
  name varchar(200) not null,
  address varchar(500) not null,
  ward_no integer not null,
  gender varchar(10) not null,
  age integer not null
);

alter table voters auto_increment=1000;
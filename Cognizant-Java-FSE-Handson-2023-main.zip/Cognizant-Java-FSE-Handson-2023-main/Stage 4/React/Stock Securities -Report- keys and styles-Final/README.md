### Stock Securities -Report- keys and styles-Final

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/54b8cb8e-b389-4af3-b007-8ffb6576e85a)
![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/ca2a732b-043b-4285-a5ca-3ee3030199dc)

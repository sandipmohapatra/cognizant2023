// Please do not make any changes in the given template
import React from 'react';
import ReactDOM from 'react-dom';
import Register from './Register.js';


ReactDOM.render(<Register />, document.getElementById('root'));
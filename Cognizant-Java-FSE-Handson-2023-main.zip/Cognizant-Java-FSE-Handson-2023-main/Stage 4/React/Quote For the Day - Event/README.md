### Quote For the Day - Event

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/306c9a22-2428-48fe-9ce6-c3bb2c4eaecb)

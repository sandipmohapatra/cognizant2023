### FunTimeTicket - PropTypes

**Problem Specification**

![r1](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/eaee3752-e2c9-4717-9ff1-85f5e04635f3)

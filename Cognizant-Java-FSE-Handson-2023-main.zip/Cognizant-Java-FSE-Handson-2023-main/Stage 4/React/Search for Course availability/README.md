### Search for Course availability

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/34c82e6c-e6ac-40a8-a39c-288170b7241b)
![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/36d69bc1-06d0-45fe-b4f5-696bd41ca1d6)
![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/b714d622-539b-407b-b98c-4632312b6321)

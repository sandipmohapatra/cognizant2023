// Please do not make any changes in the given code template
import React from 'react';
import ReactDOM from 'react-dom';
import CourseDetails from './CourseDetails';
import * as serviceWorker from './serviceWorker';


ReactDOM.render(<CourseDetails/>, document.getElementById('root'))
serviceWorker.unregister();

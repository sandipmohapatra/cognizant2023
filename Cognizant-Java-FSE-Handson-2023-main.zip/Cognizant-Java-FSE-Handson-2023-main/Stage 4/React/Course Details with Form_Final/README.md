### Course Details with Form_Final

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/2d0999e8-bbe4-4d82-865a-ced758567834)
![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/d8774634-7e68-45e1-be89-1802930e93e1)

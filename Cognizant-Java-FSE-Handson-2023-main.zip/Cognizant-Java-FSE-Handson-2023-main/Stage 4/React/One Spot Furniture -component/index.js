// Please do not make any changes in the given template
import React from 'react';
import ReactDOM from 'react-dom';

import Welcome from './Stock';
import * as serviceWorker from './serviceWorker';



ReactDOM.render(<Welcome />, document.getElementById('root'))
serviceWorker.unregister();




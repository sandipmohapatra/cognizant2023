import React from 'react';
import './Styles.css';

//Create a function named Welcome() and display the text as per the given description
function Welcome(){
    return (
        <div>
        <h1>Welcome to One Spot Furniture Mart</h1>
        </div>
    );
}

export default Welcome;


// export the default component

### Sort Applicants List_Final

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/d10769ab-41bb-40e6-9ac6-8fd46bb48b61)
![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/1e49f945-d541-4463-b651-70673b12aabf)

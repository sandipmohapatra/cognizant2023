import React from 'react';
import './style.css';
class Contact extends React.Component {
   render() {
      return (
          <div>
            <h1>Contact Component</h1>
            </div>
          
          );
   }
}
export default Contact;
### Angular

By completing Angular/React Milestone you will learn

- Components
- Different types of forms
- Routing concept
- Application testing using Karma/Jest

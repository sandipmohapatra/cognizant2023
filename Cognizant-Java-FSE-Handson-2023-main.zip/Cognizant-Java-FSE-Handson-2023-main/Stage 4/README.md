## Stage 4 - FSE Skills - Part II

- Docker
- Angular
- Application debugging - Frontend
- React

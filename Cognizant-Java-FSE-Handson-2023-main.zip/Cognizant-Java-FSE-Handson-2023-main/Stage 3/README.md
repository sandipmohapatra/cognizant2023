## Stage 3 - FSE Skills - Part I

- Application debugging - Backend
- Spring Data JPA with Spring Boot
- Spring REST using Spring Boot
- Microservices

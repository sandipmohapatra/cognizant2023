By completing **"Microservices"**, you will learn

- Microservices using Spring Web
- Eureka Discovery Services using Spring Cloud
- Zuul Gateway to route multiple Microservices

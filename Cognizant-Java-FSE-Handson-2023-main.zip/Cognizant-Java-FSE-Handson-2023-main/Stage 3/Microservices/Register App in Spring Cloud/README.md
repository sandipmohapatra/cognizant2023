### Register App in Spring Cloud


**Register App in Spring Cloud**

[Click here to download the code skeleton](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231745/mod_vpl/intro/ProductApp.zip)

[Click here to download the problem statement](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231745/mod_vpl/intro/Microservice%20-%20Register%20App%20in%20Spring%20Cloud.docx)

### Course Management - Exception Handling
**Course Management System**

ZEE Tech Software solutions has already implemented the Spring REST solution for course management. Client has a new requirement to create a REST web service along with exception handling . Help Zee-Tech to automate the above process by developing Rest Service using Maven.

[Click here to download the problem statement.](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231732/mod_vpl/intro/Course%20Management.docx?time=1679899008320)

### Service Provider System - Put and Delete
**Online Zee-tech Mobile Connection**


Online Zee-tech Mobile Connection provider wanted to use a webservice for obtaining the new connection , modifying the connection type, revoke the connection and viewing the connection details. Help Zee-tech to automate the above process by developing Rest Service using Maven to modify and delete a connection.

[Click here to download the problem statement](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231731/mod_vpl/intro/Service%20Provider%20System%20-%20Put%20and%20Delete.docx?time=1679898729078)

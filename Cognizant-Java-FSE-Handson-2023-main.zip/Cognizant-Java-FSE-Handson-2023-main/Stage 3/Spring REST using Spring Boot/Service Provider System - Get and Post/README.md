### Service Provider System - Get and Post
**Online Zee-tech Mobile Connection**

Online Zee-tech Mobile Connection provider wanted to use a webservice for obtaining the new connection , modifying the connection type, revoke the connection and viewing the connection details. 

Help Zee-tech to automate the above process by developing Rest Service using Maven to add and retrieve the connection details.

[Click here to download the problem statement](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231730/mod_vpl/intro/Service%20Provider%20Automation_v1.docx?time=1679897752386)

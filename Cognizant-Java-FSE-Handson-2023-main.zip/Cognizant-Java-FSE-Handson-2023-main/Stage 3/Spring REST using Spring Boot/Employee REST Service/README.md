### Employee REST Service
Employee REST Controller App

Global technologies wanted to use a web service for manipulating the Employee details.  To start with they need a web service to view all the employee details. 

Help them to automate the above process by developing Rest Service using Maven to retrieve the employee details.

[Click here to download the problem statement](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231729/mod_vpl/intro/Employee%20REST%20App.docx?time=1679895796149)

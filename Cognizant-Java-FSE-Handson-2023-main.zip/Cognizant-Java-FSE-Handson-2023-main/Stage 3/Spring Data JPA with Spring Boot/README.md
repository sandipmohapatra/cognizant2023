By completing **“Spring Data JPA”**,you will learn

- Introduction to ORM, Hibernate and JPA
- ORM implementation with Hibernate
- DML using Spring Data JPA
- O/R Mapping
- HQL

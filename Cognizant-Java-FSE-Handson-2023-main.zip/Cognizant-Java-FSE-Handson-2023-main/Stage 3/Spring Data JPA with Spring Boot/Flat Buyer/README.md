### Flat Buyer


Meraas Builders wants to store and manipulate the details of their buyers to whom they have sold flats from their new apartment. Develop a Spring Data JPA application to perform the task.

[Click here to download the problem statement](https://cognizant.tekstac.com/mod/vpl/viewfile.php/231549/mod_vpl/intro/Flat%20Buyer.docx?time=1679553476340)

## Stage 1 - Core Programming Fundamentals

- User Interface Design
- SQL Programming
- Java Programming Fundamentals

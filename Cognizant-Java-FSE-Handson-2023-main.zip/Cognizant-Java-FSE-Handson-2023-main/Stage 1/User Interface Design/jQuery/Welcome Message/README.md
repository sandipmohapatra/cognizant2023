### Welcome Message

Create a web pagewhich should contain an input box, Ok button, and a p tag with the id address.  When the user entershis/her name into the text box, display a welcome message using jQuery. 


Please refer to the sample page for more clarifications.

Sample Page:

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/d76b27ba-9138-4532-98ed-5379eacf10c6)


Note: 

Do not alter the given 'welcome.html' file.  Write your jQuery code in the file 'welcome.js'.

Avoid writing the jQuery 'document ready' method for the proper web page visibility.

Do not use 'ES6' features.

$('p').css('color', 'orange');
$('ul[class="flavours"] li').css({ 'background-color': 'lightblue', 'font-size': '120%' });
$('ul[id="icecreamfloats"] li').css('background-color', 'orange');
$("body p:nth-child(2)").css('font-size', '50%');
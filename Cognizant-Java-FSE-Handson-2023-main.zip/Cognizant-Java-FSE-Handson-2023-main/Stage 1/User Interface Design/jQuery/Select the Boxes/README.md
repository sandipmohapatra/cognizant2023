### Select the Boxes

Design an HTML page that contains four checkboxes with the values: Red, Green, Blue, and Black.    UsingjQuery functions you have to check whether the checkboxes are checked or notand also display a number of checkboxes checked.  Create a <div> tag with the id "result" to display the message as specified in the below images.

Note: 

- Do not alter the given 'chkbox.html' file.  Write your jQuery code in the file 'chkbox.js'.
- Avoid writing the jQuery 'document ready' method for the proper web page visibility.
- Do not use 'ES6' features.


----------

1. Sample HTML page before checked:

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/ef77d18e-1484-4ce3-9634-5f9b438ecde6)


2. Sample HTML page after checking one check box:

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/b77743db-023e-42b2-921e-33c04bab2199)




3. Sample HTML page after checking three checkboxes:

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/b063fd38-f758-4b81-9993-f9014a1e473b)





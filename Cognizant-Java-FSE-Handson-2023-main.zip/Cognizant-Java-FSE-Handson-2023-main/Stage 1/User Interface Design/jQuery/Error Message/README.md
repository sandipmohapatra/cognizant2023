### Error Message
Create an HTML page that should display the error statusmessage when the user clicks the button Click to Get the Employee Data  with the id btn-id to load the JSON fileemployee.json does not exist. Use jquery ajax() to perform the task. Display the error message Error Message: Not found in a div tag withthe id err-id.


Note:

1. Do not alter the files employee.html
2. Write your code in employee.js file
3. Avoid writing the jQuery 'document ready' method for the proper web page visibility.
4. Do not use 'ES6' features.




Sample Page:

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/05d1826c-22c2-4225-bfad-ac6a8ca45afb)

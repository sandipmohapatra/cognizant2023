### Three Divisions

Design  anhtml page with three divisions(using div tag), which should contains followingattributes:

`<div> tag 1:`          &nbsp;   &nbsp;&nbsp;  &emsp;      &emsp;&emsp;&emsp;&emsp;                  `<div> tag 2:`                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;                             `<div> tag 3:`

Name : DAIntelligence         &emsp;&emsp;&emsp;         Name : ASI_Intelligence                &emsp;&emsp;&emsp;     Name : Intelligence-Amp

 

Each division contains a paragraph tag (`<p>`)with the texts given below:

`<p> tag 1: Distributed Artificial Intelligence(DAI)`

`<p> tag 2: Artificial Super Intelligence (ASI)`

`<p> tag 3: Intelligence Amplification (IA)`

 UsingjQuery finds all the divisions with an attribute name that ends with 'Intelligence'and sets the background color yellow when the user click on the button Clickto see the effect.

Note: 

Do not alter the given 'divisions.html' file.  Write your jQuery code in the file 'divisions.js'.


Avoid writing the jQuery 'document ready' method for the proper web page visibility.

Do not use 'ES6' features.


Sample Page:

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/136a8f7b-d539-4dd7-b16b-50740da136bc)




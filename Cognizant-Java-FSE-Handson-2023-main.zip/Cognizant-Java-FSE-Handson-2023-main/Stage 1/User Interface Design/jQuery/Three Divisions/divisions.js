$('#button1').click(function() {
    $("div[name$='Intelligence']").css("background-color", "yellow");
});
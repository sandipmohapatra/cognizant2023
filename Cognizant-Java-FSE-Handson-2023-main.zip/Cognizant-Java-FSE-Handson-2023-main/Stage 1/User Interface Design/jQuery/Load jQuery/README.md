### Load jQuery
Ron recently started his carrier in developing web applications.  As a part of his first project, he is assigned to create a web page using jQuery library.  He created the web page and now he wants to check whether jQuery is loaded on his web page or not.  For this, he wants to display a message jQuery is loaded!!! on his web page when the page is loaded.  Help Ron to perform the task.

Note: 

Do not alter the given 'load.html' file.  Write your jQuery code in the file 'load.js'

Avoid writing the jQuery 'document ready' method for the proper web page visibility.

Do not use 'ES6' features.

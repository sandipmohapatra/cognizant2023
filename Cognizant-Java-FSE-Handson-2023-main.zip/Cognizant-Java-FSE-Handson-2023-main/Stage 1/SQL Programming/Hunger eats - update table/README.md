### Hunger eats - update table

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/4f0ce0c9-6bd6-4fe8-a1ba-ca16b80b429b)

Update records based on the given requirement.

Requirement 1: update the phone no of the Customers whose id is 'CUST1004' to the new phone no  '9876543210'

**NOTE:** Maintain the same sequence of column order, as specified in the question description.

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/df58f0fa-73df-4ec3-a0eb-1c160d285893)

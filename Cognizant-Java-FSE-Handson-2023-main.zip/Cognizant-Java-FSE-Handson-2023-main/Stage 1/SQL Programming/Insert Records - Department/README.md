### Insert Records - Department

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/167265a8-de2f-4ecd-8c7b-428c9ee1627b)

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/dbbdc587-a59b-4d1d-bda3-30a33242bef4)


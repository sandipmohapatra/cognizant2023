### Department name based on block number

Write a query to display the names of the departments in block number 3. Sort the records in ascending order.

(HINT: Use department table to retrieve records.)

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/c7b3c562-4140-4af5-88d1-3f90e3270ba5)


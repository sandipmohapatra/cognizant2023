### Customers having gmail id

Write a query to display customer id, customer name, address, and phone number of customers having Gmail id.  Sort the result based on customer id.

(HINT: Use Customers table to retrieve records. Email id='xxxxx@gmail.com'.Data is case sensitive.)

**NOTE:** Maintain the same sequence of column order, as specified in the question description

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/d9f1a12d-45b7-4c73-a5d3-118404b57666)

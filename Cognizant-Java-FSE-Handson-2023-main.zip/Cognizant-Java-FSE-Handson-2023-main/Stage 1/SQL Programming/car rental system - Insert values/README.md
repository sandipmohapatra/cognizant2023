### car rental system - Insert values

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/5f5332f0-0e9c-4760-880b-84b8a71e3510)

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/e8f48d91-8a94-41d6-a334-1d9e5a86d807)


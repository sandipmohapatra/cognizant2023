### Delivery Partner details based on rating

Write a query to display partner id, partner name, phone number of delivery partners whose rating is between 3 to 5, sort the result based on partner id.

(Hint: Use Delivery_partners table to retrieve records.)

**NOTE:** Maintain the same sequence of column order, as specified in the question description

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/c61bd1eb-e99c-4385-add1-4de9b3b11de5)

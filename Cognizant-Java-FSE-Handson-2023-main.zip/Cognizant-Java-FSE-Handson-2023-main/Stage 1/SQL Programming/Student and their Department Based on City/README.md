### Student and their Department Based on City



Write a query to display list of students name and their department name who are all from 'Coimbatore'. Sort the result based on students name  

(HINT: Use department and student tables to retrieve records.)

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/5cdb4ae1-80b5-4f1e-8cf9-d50d2595f38b)

### Customer using HDFC bank

Write a query to display the unique user name and their city who have booked their tickets by not using the HDFC bank for any of the bookings. Sort the result based on the user name.

(HINT: Use users and bookingdetails tables to retrieve records.)

(Note: Evaluate only the respective query to get the desired result. **Data is case sensitive.**

**Maintain the same sequence of column order as given in the problem description)**

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/fcf1a962-8e30-4e90-baaf-30ff82233ec0)

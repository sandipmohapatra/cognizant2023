### Concatenating Details



Write a query to display address details by concatenating address and city of students . Give an alias as Address and sort the result based on the concatenated column in descending order

Example: 

           Address - Toms Town

          City - Bangalore

Output:

           Toms Town, Bangalore

**(HINT: Use student table to retrieve records.)**

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/f824ce1f-efc7-488f-9371-c664b1c17ae1)



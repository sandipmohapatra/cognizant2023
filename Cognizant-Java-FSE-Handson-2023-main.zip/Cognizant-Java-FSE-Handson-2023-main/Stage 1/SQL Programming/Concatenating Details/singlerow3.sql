select CONCAT(address,", ", city) as address from student order by address desc;

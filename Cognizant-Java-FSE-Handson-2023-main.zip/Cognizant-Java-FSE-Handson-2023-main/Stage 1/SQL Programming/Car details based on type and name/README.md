### Car details based on type and name

Write a query to display car id, car name and car type of Maruthi company 'Sedan' type cars.  Sort the result based on car id.

(HINT : Use Cars table to retrieve records.car name='Maruthi Swift'.car type='Sedan'.Data is case sensitive.)

**NOTE: Maintain the same sequence of column order, as specified in the question description**

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/dd77fff8-5697-42c9-969b-e5f1ed9e3a25)

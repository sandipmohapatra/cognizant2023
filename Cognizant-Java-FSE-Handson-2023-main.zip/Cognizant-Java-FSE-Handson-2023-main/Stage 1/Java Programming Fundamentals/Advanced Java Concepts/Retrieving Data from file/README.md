### Retrieving Data from file
Allen started working with I/O in java. Allan's mam has written some contents in the log.txt file. Help Allen to write a java code to display the contents of the file in the console.

Note:

Do not change the Code Skeleton

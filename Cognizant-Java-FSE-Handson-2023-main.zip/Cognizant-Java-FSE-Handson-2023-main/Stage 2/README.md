## Stage 2 - Application Frameworks

- Data Structures and Algorithms
- Spring Core, Maven
- Unit Testing, Code Quality
- Logging and Code Quality

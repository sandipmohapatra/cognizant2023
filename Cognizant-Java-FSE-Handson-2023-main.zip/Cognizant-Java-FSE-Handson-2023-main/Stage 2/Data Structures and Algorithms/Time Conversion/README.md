### Time Conversion
[Click here to access the Hands On](https://www.hackerrank.com/challenges/time-conversion/problem)

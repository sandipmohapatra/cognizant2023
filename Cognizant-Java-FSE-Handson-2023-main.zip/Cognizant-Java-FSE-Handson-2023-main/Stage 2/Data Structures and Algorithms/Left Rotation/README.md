### Left Rotation
[Click here to access the Hands On](https://www.hackerrank.com/challenges/array-left-rotation/problem)


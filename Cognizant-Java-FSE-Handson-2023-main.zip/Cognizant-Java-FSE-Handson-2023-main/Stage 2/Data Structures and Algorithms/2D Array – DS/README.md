### 2D Array – DS
[Click here to access the Hands On](https://www.hackerrank.com/challenges/2d-array/problem)

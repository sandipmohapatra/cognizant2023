### Mini-Max Sum
[Click here to access the Hands On](https://www.hackerrank.com/challenges/mini-max-sum/problem)

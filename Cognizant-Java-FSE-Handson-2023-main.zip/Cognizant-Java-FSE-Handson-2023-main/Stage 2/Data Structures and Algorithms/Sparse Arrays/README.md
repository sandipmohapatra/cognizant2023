### Sparse Arrays
[Click here to access the Hands On](https://www.hackerrank.com/challenges/sparse-arrays/problem)

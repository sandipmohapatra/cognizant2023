
### Arrays – DS
[Click here to access the Hands On](https://www.hackerrank.com/challenges/arrays-ds/problem)

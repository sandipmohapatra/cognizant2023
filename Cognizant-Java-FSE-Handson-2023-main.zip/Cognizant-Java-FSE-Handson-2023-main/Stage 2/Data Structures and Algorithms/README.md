## Overview - Data Structures and Algorithms

By completing **"Data Structures and Algorithms"**, you will learn

- Data Structures
  - Array
  - LinkedList
- Algorithms
  - Sorting 
  - Searching

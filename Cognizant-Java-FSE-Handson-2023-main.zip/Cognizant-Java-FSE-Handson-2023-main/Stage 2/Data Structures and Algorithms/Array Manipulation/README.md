### Array Manipulation
[Click here to access the Hands On](https://www.hackerrank.com/challenges/crush/problem)

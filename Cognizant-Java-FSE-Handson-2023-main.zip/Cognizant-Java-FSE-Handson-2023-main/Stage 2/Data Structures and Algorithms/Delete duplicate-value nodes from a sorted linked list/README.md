### Delete duplicate-value nodes from a sorted linked list
[Click here to access the Hands On](https://www.hackerrank.com/challenges/delete-duplicate-value-nodes-from-a-sorted-linked-list/problem)

## Overview - Spring Core, Maven

By completing  **"Spring Core, Maven"**, you will be able to learn

- Maven Concepts
- Spring Dependency Injection
- Spring Aspect oriented Programming Concepts
- Spring JDBC Template

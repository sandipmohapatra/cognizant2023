### EngineAnalysis




[Click here to download the Code Skeleton](https://cognizant.tekstac.com/mod/vpl/viewfile.php/181065/mod_vpl/intro/EngineAnalysis.zip)

[Click here to download the problem statement](https://cognizant.tekstac.com/mod/vpl/viewfile.php/181065/mod_vpl/intro/EngineAnalysis%20%28Constructor%20Injection%29.docx) 

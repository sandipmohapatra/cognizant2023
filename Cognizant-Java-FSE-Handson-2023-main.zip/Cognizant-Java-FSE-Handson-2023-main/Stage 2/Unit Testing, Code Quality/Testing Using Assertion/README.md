### Testing Using Assertion
Write JUNIT test class named CustomerTest to test the attributes given in the Customer class.

(i)   Test whether the Aadhar card no is valid or not by using assertTrue() and assertFalse() methods. The Aadhaar card number should contain 12 digits. It should not start with 0 or 1.

(ii)  Test whether the firstname and lastname are not equal by using assertNotEquals() method

(iii) Test whether the Email id is not null by using assertNotNull() method

 You need to write only JUNIT code.

Note: Do not alter the code present inside the Customer class.

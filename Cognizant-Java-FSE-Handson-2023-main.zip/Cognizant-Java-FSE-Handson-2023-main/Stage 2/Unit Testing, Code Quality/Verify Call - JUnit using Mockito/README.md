### Verify Call - JUnit using Mockito



[Click here to download the code skeleton](https://cognizant.tekstac.com/mod/vpl/viewfile.php/181081/mod_vpl/intro/VerifyCall.zip)

## Overview - Unit Testing, Code Quality

By completing  **"Unit Testing and Code Quality"**, you will be able to learn

- Test Driven Development, Junit, Mockito
- Code Quality – PMD rules , code refactoring

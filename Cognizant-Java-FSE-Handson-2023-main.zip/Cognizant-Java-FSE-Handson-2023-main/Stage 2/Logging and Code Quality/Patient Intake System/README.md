### Patient Intake System
[Click here to download the question description.](https://cognizant.tekstac.com/pluginfile.php/177057/mod_assign/intro/Patient%20Intake%20system.docx)

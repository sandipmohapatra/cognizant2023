### Flight Management
[Click here to download the question description.](https://cognizant.tekstac.com/pluginfile.php/177056/mod_assign/intro/Flight%20Management.docx)

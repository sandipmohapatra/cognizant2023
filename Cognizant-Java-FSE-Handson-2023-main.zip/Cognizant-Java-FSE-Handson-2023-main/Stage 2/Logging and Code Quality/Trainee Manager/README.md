### Trainee Manager
[Click here to download the question description.](https://cognizant.tekstac.com/pluginfile.php/177058/mod_assign/intro/Trainee%20manager.docx)

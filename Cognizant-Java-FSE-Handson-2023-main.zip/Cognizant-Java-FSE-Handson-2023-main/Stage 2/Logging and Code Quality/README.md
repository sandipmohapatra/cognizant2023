## Overview - Logging and Code Quality

By completing **“Logging and Code Quality”**, you will learn

- SLF4J ,Lombok , Log4J
- SONAR

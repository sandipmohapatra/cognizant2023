# Java FSE Internship at Cognizant, 2023

![image](https://github.com/abhisheks008/Cognizant-Java-FSE-Hands-ons-2023/assets/68724349/c6f75761-b2c6-466d-8cba-6b4f1d2122c6)


The Java FSE training program is divided into four stages, with a total duration of 16 weeks. Here is the breakdown of the weeks allocated to each stage:

- Stage 1 - 5 weeks

- Stage 2 - 4 weeks

- Stage 3 - 3 weeks

- Stage 4 - 4 weeks

During the training, interns will progress through these stages, with each stage focusing on specific topics and skill development. It is important to note that the duration of each stage may vary depending on the training program and organizational requirements.

-- MySQL dump 10.13  Distrib 5.5.15, for Win32 (x86)
--
-- Host: localhost    Database: mission
-- ------------------------------------------------------
-- Server version	5.5.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `salary_scheme_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `manager_id` (`manager_id`),
  KEY `salary_scheme_id` (`salary_scheme_id`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`salary_scheme_id`) REFERENCES `salary_scheme` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1001,'Avinash','Pune','Team Lead','7012345689',NULL,1),(1002,'Subhash','Pune','Tester','7212345689',1001,2),(1003,'Anthash','Coimbatore','Team Lead','8012345689',NULL,1),(1004,'Avinash','Kolkata','Developer','7712345689',1003,3),(1005,'Vivek','Pune','Developer','7512345689',1003,3),(1006,'Manish','Hyderabad','Tester','8512345689',1001,3),(1007,'Aparna','Coimbatore','UI Designer','9052345689',1002,3),(1008,'Zahira','Kolkata','UI Designer','8012345689',1003,3),(1009,'Sujoy','Hyderabad','Senior Developer','8512345689',1001,1),(1010,'Arpita','Kochi','Senior Tester','9812345689',1002,2),(1011,'Kritika','Pune','Developer','9812345689',1002,2),(1012,'Kusum','Kolkata','Tester','8672345689',1003,3),(1014,'Zubin','Hyderabad','Junior Tester','6587459632',1006,3);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_detail_entry`
--

DROP TABLE IF EXISTS `leave_detail_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_detail_entry` (
  `id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `allowed_count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_type_id` (`leave_type_id`),
  CONSTRAINT `leave_detail_entry_ibfk_1` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_detail_entry`
--

LOCK TABLES `leave_detail_entry` WRITE;
/*!40000 ALTER TABLE `leave_detail_entry` DISABLE KEYS */;
INSERT INTO `leave_detail_entry` VALUES (101,1,12),(102,2,18),(103,3,90);
/*!40000 ALTER TABLE `leave_detail_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_details`
--

DROP TABLE IF EXISTS `leave_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_details` (
  `id` int(11) NOT NULL,
  `leave_detail_entry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_detail_entry_id` (`leave_detail_entry_id`),
  CONSTRAINT `leave_details_ibfk_1` FOREIGN KEY (`leave_detail_entry_id`) REFERENCES `leave_detail_entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_details`
--

LOCK TABLES `leave_details` WRITE;
/*!40000 ALTER TABLE `leave_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_request`
--

DROP TABLE IF EXISTS `leave_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_request` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `requested_date` date NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `approved_by` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  KEY `approved_by` (`approved_by`),
  KEY `leave_type_id` (`leave_type_id`),
  CONSTRAINT `leave_request_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `leave_request_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `employee` (`id`),
  CONSTRAINT `leave_request_ibfk_3` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_request`
--

LOCK TABLES `leave_request` WRITE;
/*!40000 ALTER TABLE `leave_request` DISABLE KEYS */;
INSERT INTO `leave_request` VALUES (1,1005,'2018-03-12','2018-03-20','2018-03-20','approved',1003,1),(2,1009,'2018-05-20','2018-05-17','2018-05-19','approved',1001,2),(3,1008,'2018-07-29','2018-07-30','2018-07-31','rejected',1003,1),(4,1008,'2018-08-02','2018-08-05','2018-08-06','approved',1003,1),(5,1011,'2018-09-20','2018-09-25','2018-09-27','approved',1002,2),(6,1012,'2018-09-20','2018-10-01','2018-10-30','rejected',1003,3),(7,1011,'2018-10-20','2018-10-25','2018-10-25','approved',1002,1),(8,1012,'2018-10-20','2018-10-25','2018-10-25','rejected',1003,1),(9,1014,'2018-11-15','2018-11-20','2018-11-24','approved',1006,2),(10,1007,'2018-11-30','2018-11-25','2018-11-30','approved',1002,2),(11,1007,'2018-12-15','2018-12-24','2018-12-24','rejected',1002,1);
/*!40000 ALTER TABLE `leave_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_type`
--

DROP TABLE IF EXISTS `leave_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_type`
--

LOCK TABLES `leave_type` WRITE;
/*!40000 ALTER TABLE `leave_type` DISABLE KEYS */;
INSERT INTO `leave_type` VALUES (1,'Casual Leave','One per month allowed'),(2,'Sick Leave','Medical Reason required'),(3,'Study Leave','Max of three months allowed after 2 years of work');
/*!40000 ALTER TABLE `leave_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `overtime`
--

DROP TABLE IF EXISTS `overtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `overtime` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `working_date` date NOT NULL,
  `over_time_hours` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `approved_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `overtime_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`),
  CONSTRAINT `overtime_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `employee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `overtime`
--

LOCK TABLES `overtime` WRITE;
/*!40000 ALTER TABLE `overtime` DISABLE KEYS */;
INSERT INTO `overtime` VALUES (1,1012,'2018-08-20',2,'approved',1003),(2,1008,'2018-08-22',2,'approved',1003),(3,1009,'2018-08-27',1,'approved',1001),(4,1012,'2018-09-11',2,'approved',1003),(5,1012,'2018-09-15',2,'rejected',1003);
/*!40000 ALTER TABLE `overtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_scheme`
--

DROP TABLE IF EXISTS `salary_scheme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_scheme` (
  `id` int(11) NOT NULL,
  `amount` double(11,2) NOT NULL,
  `lopPerDay` double(11,2) NOT NULL,
  `lopPerHour` double(11,2) NOT NULL,
  `overtimeAmountPerHour` double(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_scheme`
--

LOCK TABLES `salary_scheme` WRITE;
/*!40000 ALTER TABLE `salary_scheme` DISABLE KEYS */;
INSERT INTO `salary_scheme` VALUES (1,50000.00,500.00,100.00,500.00),(2,40000.00,400.00,70.00,400.00),(3,30000.00,300.00,50.00,300.00),(4,25000.00,200.00,20.00,200.00);
/*!40000 ALTER TABLE `salary_scheme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-18 16:37:10

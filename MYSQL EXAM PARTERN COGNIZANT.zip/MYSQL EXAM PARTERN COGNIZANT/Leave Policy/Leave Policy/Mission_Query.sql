-- 1. Write a query to display employee id,name 
-- from employee who acts as a manager 
-- and managers of atleast 3 employess. 
-- order by employee id.(Self join)

select m.id,m.name
from employee e  join employee m
on e.manager_id=m.id
group by m.id,m.name
having count(e.id)>=3
order by m.id;

-- 2.Write a query to display the employee id,name,Contact number
-- from employee who have taken leave for 5 continuous days in the month of November
-- and sort by emploee id. 
-- (count the number of days from to_date and from_date.)
-- Hint : He/She can take leave only if the leave_request status is 'Approved'.

select id,name,contact_number from employee
where id in(
select employee_id from leave_request
where status='approved' and month(from_date)=11
and datediff(to_Date,from_date)=5)
order by id;

-- 3.Write a query to display the employee id and designation who have taken leave for
-- more than 3 days whose name is 'Praveen'.
-- Same thing will be display for the employee whose name is 'Amarnath' and 
-- sort by employee id(descending order).
-- Hint : Use Union (In some cases for this qs it will be mention there that use Union all but U should use 'Union' only. If You use union all then it will not accepted. My own experience).

select id,designation
from employee
where id in (
select employee_id from leave_request
where status='approved'and datediff(to_Date,from_date)>3
)and name in ('Aparna','Prakash')
order by id desc;

-- 4.write a query to display unique employee id,name & designation of the employees 
-- who worked overtime in the month of ' december'.
-- display the records sorted in ascending order based on employee id.
-- note:employee can work overtime only if status is 'approved'

select distinct e.id,e.name,e.designation 
from employee e join overtime o
on o.employee_id=e.id
where month(o.working_date)=8 and o.status='approved'
order by o.employee_id;

-- 5.write a query to display the unique leave_type 
-- names taken by the employee named 'praveen' 
-- & then display the unique leave_type names 
-- taken by the employee named 'amarnath'.
-- display all the records sorted in ascending order based on leave_type name.

select distinct lt.name,e.name 
from leave_type lt join leave_request lr
on lr.leave_type_id=lt.id 
join employee e 
on e.id=lr.employee_id 
where e.name in('Zahira','Kusum')
order by lt.name

-- 6.Write a query to display the employee id,name,department of the employees who worked overtime and take leave for atleast 3
-- continuous days, sorted by emploee id.

select id,name,designation
from employee
where id in (
select employee_id from overtime
where employee_id in (
select employee_id from leave_request
where datediff(to_Date,from_date)>=3
));